<!DOCTYPE html>

<html>

	<head>
		<meta charset = 'utf-8'>
		
		<title>
			練習5
		</title>
	</head>
	
	<body>
	
		<?php
			session_start();   // 啟用交談期
			
			if (!isset($_SESSION["success"])){
				header("Location: hw5.php");
			}
		?>
	
		登入成功<p>
		<p/>
		
		<?php
			print '學號:' . $_SESSION['student_id'] . "<br>";
			print '姓名:' . $_SESSION['name'] . "<p>";

			print '!系統登入成功!' . "<p>";
			
			#session_destroy();
		?>
			
	</body>
	
</html>