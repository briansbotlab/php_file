<?php
	session_start();
	
	$file  = basename($_SERVER["PHP_SELF"],".php");
	$path  = realpath($file.".php");                    // 取得檔案實際路徑
	$parts = pathinfo($path);                           // 取得路徑資訊
	
	
   
	
	if (isset($_POST['student_id'])  and isset($_POST['password'])) {
		$student_id = $_POST["student_id"];
		
		$password = $_POST['password'];
	}
	else {
		header('Location: hw5.php');
	}
	
	
	$readfile  = $parts["dirname"] . "\\score.dat";
	$line = fscanf($fpin, "%s %s %s %s %s %s");
   
	
	
	while ($line != null) {
		list($sid, $pass, $name, $ch,$en,$math ) = $line;
		if ($student_id ==$sid and $password == $pass) {
			$_SESSION['success'] = 'yes';
			
			$_SESSION['student_id'] = $student_id;
			$_SESSION['password'] = $password;
			$_SESSION['name'] = $name;
			$_SESSION['ch'] = $ch;
			$_SESSION['en'] = $en;
			$_SESSION['math'] = $math;
			header('Location: success.php');
			
		}
		$line = fscanf($fpin, "%s %s %s %s %s %s");
		
	}
	
	
	
	$_SESSION['student_id'] = $student_id;

	header('Location: fail.php');
		
?>