<!DOCTYPE html>

<html>

	<head>
		<meta charset = 'utf-8'>
		
		<title>
			練習5
		</title>
	</head>
	
	<body>
	
		<?php
			session_start();   // 啟用交談期
			
			#if (!isset($_SESSION["success"])){
				#header("Location: hw5.php");
			#}
		?>
	
		登入失敗<p>
		<p/>
		
		<?php
			print '學號:' . $_SESSION['student_id'] . "<br>";
			

			print '!系統登入失敗!' . "<p>";
			
			#session_destroy();
		?>
		
		<a href = 'hw5.php'>回系統登入畫面</a>
			
	</body>
	
</html>